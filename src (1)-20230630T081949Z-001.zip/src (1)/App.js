import Kiosk from "./components/kiosk";
import Todo1 from "./components/todo1";




function App() {

  return (
    <div>
       <Todo1></Todo1>     
    </div>
  );
}

export default App;
